package eightPuzzle;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class Board
{
	int N;
	int[] board;
	
	Board(int board[])
	{
		N=(int)Math.sqrt((double)board.length);
		this.board=new int[board.length];
		for(int i=0;i<N*N;i++)
		{
			this.board[i]=board[i];
		}
	}
	
	Board(int[][] blocks)
	{
		N=blocks[0].length;
		board=new int[N*N];
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				this.board[i*N+j]=blocks[i][j];
			}
		}
	}
	
	public boolean isGoal()
	{
		for(int i=0;i<N*N-1;i++)
		{
			if(board[i]!=i+1)
				return false;
		}
		return true;
	}
	
	public Board exchange(Board a, int i, int j)
	{
		int temp=a.board[i];
		a.board[i]=a.board[j];
		a.board[j]=temp;
		return a;
	}
	
	public Iterable<Board> neighbors()
	{
		Queue<Board> b=new LinkedList<Board>();
		int index=0;
		Board neighbor;
		for(int i=0;i<board.length;i++)
		{
			if(board[i]==0)
			{
				index=i;
				break;
			}
		}
		if(index/N!=0)
		{
			neighbor=new Board(board);
			neighbor=exchange(neighbor, index, index-N);
			b.add(neighbor);
		}
		if(index/N!=(N-1))
		{
			neighbor=new Board(board);
			neighbor=exchange(neighbor, index, index+N);
			b.add(neighbor);
		}
		if(index%N!=0)
		{
			neighbor=new Board(board);
			neighbor=exchange(neighbor, index, index-1);
			b.add(neighbor);
		}
		if(index%N!=(N-1))
		{
			neighbor=new Board(board);
			neighbor=exchange(neighbor, index, index+1);
			b.add(neighbor);
		}
		
		return b;
	}
	
	public boolean equals(Object y)
	{
		if(y==this)
			return true;
		if(y==null)
			return false;
		if(y.getClass()!=this.getClass())
			return false;
		
		Board that=(Board)y;
		return (Arrays.equals(that.board,this.board));
	}
	
	public int manhatton()
	{
		int sum=0;
		for(int i=0;i<N*N;i++)
		{
			if(board[i]!=i+1 && board[i]!=0)
				sum+= manhattan(board[i], i);
		}
		return sum;
	}
	
	public int manhattan(int goal, int current)
	{
		int row, col;
		row=Math.abs((goal-1)/N-current/N);
		col=Math.abs((goal-1)%N-current%N);
		//System.out.println("g="+row+"\t h="+col);
		return row+col;
	}
}