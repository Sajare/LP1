package eightPuzzle;

import java.util.*;

public class Solver
{
	private static SearchNode goal;
	private class SearchNode
	{
		Board current;
		int moves;
		SearchNode prev;
		SearchNode(Board initial)
		{
			current=initial;
			prev=null;
			moves=0;
		}
	}
	
	class PriorityOrder implements Comparator<SearchNode>
	{
		public int compare(SearchNode n1, SearchNode n2)
		{
			int ma, mb;
			ma=n1.current.manhatton()+n1.moves;
			mb=n2.current.manhatton()+n2.moves;
			if(ma>mb)
				return 1;
			if(ma<mb)
				return -1;
			else
				return 0;
		}
	}
	
	public Solver(Board initial)
	{
		PriorityOrder po=new PriorityOrder();
		PriorityQueue<SearchNode> pq=new PriorityQueue<SearchNode>(po);
		int counter=0;
		SearchNode node=new SearchNode(initial);
		pq.add(node);
		SearchNode min=pq.remove();
		while(!min.current.isGoal()) 
		{
			if(counter++==1500)
			{
				System.out.println("\nTaking long time, unsolvable.");
				System.exit(0);
			}
			for(Board b: min.current.neighbors())
			{
				if(min.prev==null || !b.equals(min.prev.current))
				{
					SearchNode n=new SearchNode(b);
					n.prev=min;
					n.moves=min.moves+1;
					pq.add(n);
				}
			}
			min=pq.remove();
		}
		if(min.current.isGoal())
			goal=min;
		else
			goal=null;
	}
	
	public boolean isSolvable()
	{
		return goal!=null;
	}
	
	public int noofmoves()
	{
		if(isSolvable())
			return goal.moves;
		else
			return -1;
	}
	
	public void printSteps(SearchNode result)
	{
		Stack<SearchNode> stk=new Stack<SearchNode>();
		while(result!=null)
		{
			stk.push(result);
			result=result.prev;
		}
		while(!stk.isEmpty())
		{
			printmatrix(stk.peek().current);
			stk.pop();
		}
	}
	
	public void printmatrix(Board board)
	{
		for(int i=0;i<board.N*board.N;i++)
		{
			if(i%3==0)
				System.out.println();
			System.out.print(board.board[i]+"  ");
		}
		System.out.println("\n-------------------------\n");
	}
	
	public static void main(String[] args)
	{
		int input[][]=new int[3][3];
		Scanner sc=new Scanner(System.in);
		System.out.println("\nEnter initial configuration : ");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				input[i][j]=sc.nextInt();
			}
		}
		
		Board initial=new Board(input);
		Solver s=new Solver(initial);
		
		if(!s.isSolvable())
			System.out.println("\nCan't be solved");
		else
		{
			System.out.println("\nNo. of Steps : "+s.noofmoves());
			s.printSteps(goal);
		}
	}
}