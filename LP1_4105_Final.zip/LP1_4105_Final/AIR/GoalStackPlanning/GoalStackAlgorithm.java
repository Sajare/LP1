import java.util.*;
public class GoalStackAlgorithm 
{
	int nos, element;
	Stacks stacks[];
	Stacks goalstacks[];
	Stacks tempstack=new Stacks();
	Scanner sc=new Scanner(System.in);
	
	public void acceptInitialState()
	{
		System.out.println("\n----------INITIAL STATE---------\n");
		System.out.println("\nEnter number of stacks : ");
		nos=sc.nextInt();
		stacks=new Stacks[nos];
		for(int i=0;i<nos;i++)
		{
			System.out.println("\nStack "+i+" Size : ");
			stacks[i]=new Stacks();
			stacks[i].stackSize=sc.nextInt();
			for(int j=0;j<stacks[i].stackSize;j++)
			{
				System.out.println("Element "+j+" : ");
				element=sc.nextInt();
				stacks[i].stack.add(new StackBean(element));
				stacks[i].stack.get(j).stackno=j;
			}
		}
		displayStates();
		StackBean e;
		for(int i=0;i<nos;i++)
		{
			Iterator<StackBean> itr=stacks[i].stack.listIterator();
			while(itr.hasNext())
			{
				e=itr.next();
				calculateheuristic(e,i,stacks[i].stack.indexOf(e));
			}
		}
	}
	
	public void acceptGoalState()
	{
		System.out.println("\n-----------GOAL STATE-----------\n");
		System.out.println("\nEnter number of stacks : ");
		nos=sc.nextInt();
		goalstacks=new Stacks[nos];
		for(int i=0;i<nos;i++)
		{
			System.out.println("\nStack "+i+" Size : ");
			goalstacks[i]=new Stacks();
			goalstacks[i].stackSize=sc.nextInt();
			for(int j=0;j<goalstacks[i].stackSize;j++)
			{
				System.out.println("Element "+j+" : ");
				element=sc.nextInt();
				goalstacks[i].stack.add(new StackBean(element));
				goalstacks[i].stack.get(j).stackno=j;
			}

		}
	}
	
	public void displayStates()
	{
		System.out.println("\n------------CURRENT STATE-----------\n");
		for(int i=0;i<nos;i++)
			System.out.println("Stack "+i+" : "+stacks[i].toString());
	}
	public void displayGoalState()
	{
		System.out.println("\n----------------GOAL STATE--------------\n");
		for(int i=0;i<nos;i++)
		{
			System.out.println("Stack "+i+" : "+goalstacks[i].toString());
		}
	}
	
	public void algorithm()
	{
		StackBean e;
		int iteration=0;
		while(!goalStateReached())
		{
			System.out.println("\n-----------Iteration "+iteration);
			System.out.println("\n========PART 1==========\n");
			//part-1: Add wrong states to the temp stack
			for(int i=0;i<nos;i++)
			{
				Iterator<StackBean> itr=stacks[i].stack.iterator();
				while(itr.hasNext())
				{
					e=itr.next();
					if(e.heuristicvalue==-1)
					{
						tempstack.stack.add(e);
						itr.remove();
					}
				}
				displayStates();
				displayTempStack();
			}
			
			System.out.println("\n=======PART 2========\n");
			//part-2: pop each state from temp stack and add to the right place
			boolean flag=false;
			while(!tempstack.stack.isEmpty())
			{
				e=tempstack.stack.pop();
				e.heuristicvalue=1;
				for(int i=0;i<nos;i++)
				{
					stacks[i].stack.push(e);
					if((flag=calculateheuristic(e,i,stacks[i].stack.indexOf(e)))==true)
					{
						break;
					}
					else
					{
						stacks[i].stack.pop();
						flag=false;
					}
				}
				if(flag=false)
				{
					e.heuristicvalue=-1;
					stacks[nos-1].stack.push(e);
				}
				displayStates();
				displayTempStack();
			}
			iteration++;
		}
	}
	
	public void displayTempStack()
	{
		System.out.println("\n----------TEMP STACK-----------\n");
		System.out.println(""+tempstack.toString());
	}
	
	public boolean calculateheuristic(StackBean e, int stacknumber, int pos)
	{
		int goalPos;
		if((goalPos=test(stacknumber,e))==pos)
		{
			stacks[stacknumber].stack.get(pos).heuristicvalue=1;
			return true;
		}
		stacks[stacknumber].stack.get(pos).heuristicvalue=-1;
		return false;
	}
	
	public int test(int stacknumber, StackBean e)
	{
		Iterator<StackBean> itr=goalstacks[stacknumber].stack.listIterator();
		StackBean s;
		while(itr.hasNext())
		{
			s=itr.next();
			if(s.state==e.state)
			{
				return goalstacks[stacknumber].stack.indexOf(s);
			}
		}
		return -1;
	}
	
	public boolean goalStateReached()
	{
		for(int i=0;i<nos;i++)
		{
			Iterator<StackBean> itr=stacks[i].stack.iterator();
			while(itr.hasNext())
			{
				if(itr.next().heuristicvalue!=1)
					return false;
			}
		}
		return true;
	}
}
