
public class InitiateAlgorithm 
{
	public static void main(String[] args)
	{
		GoalStackAlgorithm gsa=new GoalStackAlgorithm();
		gsa.acceptGoalState();
		gsa.acceptInitialState();
		gsa.displayGoalState();
		gsa.displayStates();
		gsa.algorithm();
	}
}
