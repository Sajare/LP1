
public class StackBean 
{
	int state, heuristicvalue, stackno, index;
	public StackBean()
	{
		state=0;
		heuristicvalue=0;
	}
	
	public StackBean(int element)
	{
		state=element;
		heuristicvalue=0;
	}
	
	@Override
	public String toString()
	{
		return "StackBean [ State = "+state+", Heuristic Value = "+heuristicvalue+"  ]";
	}
	
	public int getState()
	{
		return state;
	}
	
	public void setState(int state)
	{
		this.state=state;
	}
	
	public int getHeuristicValue()
	{
		return heuristicvalue;
	}
	
	public void setHeuristicvalue(boolean b)
	{
		if(b)
			this.heuristicvalue=1;
		else
			this.heuristicvalue=-1;
	}
	
}
