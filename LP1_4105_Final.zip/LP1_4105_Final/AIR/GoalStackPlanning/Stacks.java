import java.util.Stack;
public class Stacks 
{
	Stack<StackBean> stack;
	int stackSize;
	public Stacks()
	{
		super();
		this.stack=new Stack<StackBean>();
		this.stackSize=0;
	}
	@Override
	public String toString()
	{
		String str;
		str=stack.toString();
		return str;
	}
}
