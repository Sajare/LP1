import java.util.*;
public class alphaBeta 
{
	static int MAX=Integer.MAX_VALUE;
	static int MIN=Integer.MIN_VALUE;
	static int dep1;
	static void setDepth(int depth)
	{
		dep1=depth;
	}
	static int minmax(int depth, int nodeIndex, int[] values, boolean maximizingPlayer
			, int alpha, int beta)
	{
		int best;
		if(depth==dep1)
			return values[nodeIndex];
		if(maximizingPlayer)
		{
			best=MIN;
			for(int i=0;i<dep1;i++)
			{
				int val=minmax(depth+1, nodeIndex*2+i, values, false, alpha, beta);
				best=Math.max(best, val);
				alpha=Math.max(alpha, best);
				if(alpha>=beta)
					break;
			}
		}
		else
		{
			best=MAX;
			for(int i=0;i<dep1;i++)
			{
				int val=minmax(depth+1, nodeIndex*2+i, values, true, alpha, beta);
				best=Math.min(best, val);
				beta=Math.min(beta, best);
				if(alpha>=beta)
					break;
			}
		}
		return best;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int depth, values[];
		int n;
		System.out.println("\nEnter depth of tree : ");
		depth=sc.nextInt();
		n=(int)Math.pow(2, depth);
		values=new int[n];
		setDepth(depth);
		System.out.println("\nEnter "+n+"values : ");
		for(int i=0;i<n;i++)
		{
			values[i]=sc.nextInt();
		}
		int optimal_value=minmax(0,0,values,true,MIN,MAX);
		System.out.println("\nOptimal Value is : "+optimal_value);
	}
}
