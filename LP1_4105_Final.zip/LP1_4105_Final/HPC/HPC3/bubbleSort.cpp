#include<iostream>
#include<omp.h>
#include<time.h>
#include<stdlib.h>
using namespace std;

int main()
{
	int arr[60000];
	int n=60000;
	int i,j;
	double start, end;
	
	for(i=0;i<n;i++)
		arr[i]=rand()%n+1;
		
	start=omp_get_wtime();
	
	#pragma omp parallel
	{
		for(i=0;i<n;i++)
		{
			#pragma omp parallel for
			for(j=0;j<n-i-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
	}
	
	end=omp_get_wtime();
	cout<<"\nTime taken : "<<end-start<<endl;
	
	return 0;
}
