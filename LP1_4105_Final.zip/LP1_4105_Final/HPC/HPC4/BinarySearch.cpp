#include<time.h>
#include<mpi.h>
#include<iostream>
#include<cstdio>
#include<chrono>
#include<unistd.h>

using namespace std::chrono;
using namespace std;

void binarySearch(int a[], int start, int end, int key, int rank)
{
	while(start<=end)
	{
		int m=(start+end)/2;
		if(a[m]==key)
		{
			cout<<"Element found by process no. : "<<rank+1;
			return;
		}
		else if(a[m]<key)
			start=m+1;
		else
			end=m-1;
	}
	cout<<"\nElement not found.";
}

int main(int argc, char **argv)
{
	int n=20;
	int key=10;
	double c[4];
	int a[n];
	for(int i=0;i<n;i++)
		a[i]=i+1;
	
	int rank, blocksize;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &blocksize);
	blocksize=n/4;
	
	if(rank==0)
	{
		double start=MPI_Wtime();
		binarySearch(a, rank*blocksize, (rank+1)*blocksize-1, key, rank);
		double end=MPI_Wtime();
		cout<<"\nTime taken by process 1 : "<<(end-start)*1000<<endl;
		c[rank]=end;
		rank++;
		if(rank==1)
		{
			double start=MPI_Wtime();
			binarySearch(a, rank*blocksize, (rank+1)*blocksize-1, key, rank);
			double end=MPI_Wtime();
			cout<<"\nTime taken by process 2 : "<<(end-start)*1000<<endl;
			c[rank]=end;
			rank++;
			if(rank==2)
			{
				double start=MPI_Wtime();
				binarySearch(a, rank*blocksize, (rank+1)*blocksize-1, key, rank);
				double end=MPI_Wtime();
				cout<<"\nTime taken by process 3 : "<<(end-start)*1000<<endl;
				c[rank]=end;
				rank++;
				if(rank==3)
				{
					double start=MPI_Wtime();
					binarySearch(a, rank*blocksize, (rank+1)*blocksize-1, key, rank);
					double end=MPI_Wtime();
					cout<<"\nTime taken by process 4 : "<<(end-start)*1000<<endl;
					c[rank]=end;
				}
			}
		}
	}
	
	MPI_Finalize();
}
